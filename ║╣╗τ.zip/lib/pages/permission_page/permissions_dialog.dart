
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionsDialog extends StatefulWidget {
  final VoidCallback onGranted;
  const PermissionsDialog({super.key, required this.onGranted});

  @override
  State<PermissionsDialog> createState() => _PermissionsDialogState();
}

class _PermissionsDialogState extends State<PermissionsDialog> {
  String message = '위치 및 사진 권한이 필요합니다.\n앱 사용을 위해 허용해주세요.';

  Future<void> requestPermissions() async {
    final location = await Permission.location.request();
    final photos = await Permission.photos.request();

    if (location.isGranted && photos.isGranted) {
      widget.onGranted();
      Navigator.pop(context);
    } else {
      setState(() {
        message = '권한이 거부되었습니다. 설정에서 수동으로 허용해주세요.';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    requestPermissions();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('권한 요청'),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('닫기'),
        ),
        TextButton(
          onPressed: requestPermissions,
          child: const Text('다시 시도'),
        ),
      ],
    );
  }
}
