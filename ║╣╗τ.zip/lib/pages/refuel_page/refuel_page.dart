import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';

class RefuelPage extends StatefulWidget {
  const RefuelPage({Key? key}) : super(key: key);

  @override
  State<RefuelPage> createState() => _RefuelPageState();
}

class _RefuelPageState extends State<RefuelPage> {
  String? fuelType;
  File? imageFile;
  bool isLoading = false;

  final List<String> fuelOptions = ['휘발유', '경유', '전기 충전', 'LPG'];

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        imageFile = File(picked.path);
      });
    }
  }

  Future<void> submitRefuel() async {
    if (fuelType == null || imageFile == null) return;

    setState(() => isLoading = true);
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final fileName = '${uid}_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final ref = FirebaseStorage.instance.ref().child('refuels/$fileName');
    await ref.putFile(imageFile!);
    final imageUrl = await ref.getDownloadURL();

    await FirebaseFirestore.instance.collection('refuels').add({
      'uid': uid,
      'type': fuelType,
      'image': imageUrl,
      'timestamp': Timestamp.now(),
      'point': 10,
    });

    await FirebaseFirestore.instance.collection('users').doc(uid).update({
      'pointTotal': FieldValue.increment(10),
    });

    setState(() => isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('주유 인증 완료! +10P')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('⛽ 주유소 인증')),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('주유 종류 선택', style: TextStyle(fontSize: 16)),
                  DropdownButton<String>(
                    value: fuelType,
                    hint: Text('선택'),
                    isExpanded: true,
                    items: fuelOptions.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
                    onChanged: (val) => setState(() => fuelType = val),
                  ),
                  SizedBox(height: 20),
                  Text('주유 인증 사진 업로드', style: TextStyle(fontSize: 16)),
                  imageFile != null
                      ? Image.file(imageFile!, height: 150)
                      : SizedBox(height: 150, child: Placeholder()),
                  SizedBox(height: 10),
                  ElevatedButton(onPressed: pickImage, child: Text('사진 선택')),
                  Spacer(),
                  ElevatedButton(
                    onPressed: submitRefuel,
                    child: Text('인증 제출'),
                    style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(50)),
                  )
                ],
              ),
            ),
    );
  }
}
