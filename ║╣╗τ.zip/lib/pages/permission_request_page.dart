import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionRequestPage extends StatefulWidget {
  const PermissionRequestPage({Key? key}) : super(key: key);

  @override
  _PermissionRequestPageState createState() => _PermissionRequestPageState();
}

class _PermissionRequestPageState extends State<PermissionRequestPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('권한 요청')),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            var status = await Permission.location.request();
            if (status.isGranted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("위치 권한이 허용되었습니다.")),
              );
            }
          },
          child: const Text("위치 권한 요청"),
        ),
      ),
    );
  }
}
