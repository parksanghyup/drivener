import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class RepairCertPage extends StatefulWidget {
  const RepairCertPage({super.key});

  @override
  State<RepairCertPage> createState() => _RepairCertPageState();
}

class _RepairCertPageState extends State<RepairCertPage> {
  final TextEditingController amountController = TextEditingController();
  String selectedItem = '엔진오일 교체';
  File? image;

  final List<String> repairItems = [
    '엔진오일 교체',
    '브레이크 패드',
    '타이어 교체',
    '에어컨 필터',
    '기타 정비'
  ];

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        image = File(pickedFile.path);
      });
    }
  }

  Future<void> submitRepair() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || amountController.text.isEmpty || image == null) return;

    await FirebaseFirestore.instance.collection('repairs').add({
      'uid': uid,
      'item': selectedItem,
      'amount': amountController.text,
      'timestamp': Timestamp.now(),
      'image_path': image!.path,
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('정비 인증이 완료되었습니다!')),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('정비소 인증')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            // 정비 항목 선택
            DropdownButtonFormField<String>(
              value: selectedItem,
              items: repairItems.map((item) {
                return DropdownMenuItem(value: item, child: Text(item));
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedItem = val!;
                });
              },
              decoration: const InputDecoration(labelText: '정비 항목'),
            ),

            const SizedBox(height: 12),

            // 금액 입력
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '정비 금액 (원)',
              ),
            ),

            const SizedBox(height: 12),

            // 이미지 업로드
            ElevatedButton(
              onPressed: pickImage,
              child: const Text('영수증/사진 업로드'),
            ),
            if (image != null) Image.file(image!, height: 150),

            const SizedBox(height: 20),

            // 확인 버튼
            ElevatedButton(
              onPressed: submitRepair,
              child: const Text('인증 제출'),
            ),
          ],
        ),
      ),
    );
  }
}
