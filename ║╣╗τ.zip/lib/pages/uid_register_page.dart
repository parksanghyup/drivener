import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UIDRegisterPage extends StatefulWidget {
  const UIDRegisterPage({Key? key}) : super(key: key);

  @override
  State<UIDRegisterPage> createState() => _UIDRegisterPageState();
}

class _UIDRegisterPageState extends State<UIDRegisterPage> {
  final TextEditingController _uidController = TextEditingController();
  final TextEditingController _carNumberController = TextEditingController();
  final TextEditingController _carNameController = TextEditingController();

  String statusMessage = '';
  bool isLoading = false;

  Future<void> saveData() async {
    final uidText = _uidController.text.trim();
    final carNumber = _carNumberController.text.trim();
    final carName = _carNameController.text.trim();
    final user = FirebaseAuth.instance.currentUser;

    if (uidText.isEmpty || carNumber.isEmpty || carName.isEmpty || user == null) {
      setState(() => statusMessage = '모든 항목을 입력해주세요');
      return;
    }

    setState(() {
      isLoading = true;
      statusMessage = '';
    });

    final docRef = FirebaseFirestore.instance.collection('uid_list').doc(uidText);
    final docSnapshot = await docRef.get();

    if (docSnapshot.exists) {
      setState(() {
        isLoading = false;
        statusMessage = '이미 등록된 UID입니다.';
      });
      return;
    }

    await docRef.set({
      'uid': uidText,
      'userId': user.uid,
      'carNumber': carNumber,
      'carName': carName,
      'registeredAt': FieldValue.serverTimestamp(),
    });

    setState(() {
      isLoading = false;
      statusMessage = '✅ UID 등록이 완료되었습니다!';
    });

    // 페이지 뒤로 가기 + 완료 메시지
    Future.delayed(const Duration(seconds: 1), () {
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('UID 및 차량 등록')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          TextField(
            controller: _uidController,
            decoration: const InputDecoration(labelText: 'UID 입력'),
          ),
          TextField(
            controller: _carNameController,
            decoration: const InputDecoration(labelText: '차량명 (예: 소나타 N라인)'),
          ),
          TextField(
            controller: _carNumberController,
            decoration: const InputDecoration(labelText: '차량 번호 (예: 12가3456)'),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: isLoading ? null : saveData,
            child: const Text('UID 등록'),
          ),
          const SizedBox(height: 8),
          Text(
            statusMessage,
            style: TextStyle(
              color: statusMessage.contains('완료') ? Colors.green : Colors.red,
            ),
          ),
        ]),
      ),
    );
  }
}
