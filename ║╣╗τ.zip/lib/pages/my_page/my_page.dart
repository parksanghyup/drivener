import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MyPage extends StatefulWidget {
  const MyPage({super.key});

  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  final user = FirebaseAuth.instance.currentUser;
  late Future<DocumentSnapshot<Map<String, dynamic>>> userDocFuture;

  @override
  void initState() {
    super.initState();
    userDocFuture = FirebaseFirestore.instance.collection('users').doc(user!.uid).get();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('마이페이지')),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: userDocFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('사용자 정보를 불러올 수 없습니다.'));
          }

          final data = snapshot.data!.data()!;
          final uid = data['uid'] ?? '등록 안됨';
          final photoUrl = data['vehicle_photo'] ?? '';
          final totalDistance = data['total_distance']?.toStringAsFixed(2) ?? '0.0';
          final points = data['points'] ?? 0;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (photoUrl.isNotEmpty)
                  Image.network(photoUrl, height: 180),
                const SizedBox(height: 12),
                Text('UID: $uid'),
                Text('총 주행 거리: $totalDistance km'),
                Text('보유 포인트: $points P'),
                const SizedBox(height: 24),
                const Text('최근 인증 기록:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('users')
                        .doc(user!.uid)
                        .collection('certifications')
                        .orderBy('timestamp', descending: true)
                        .limit(10)
                        .snapshots(),
                    builder: (context, certSnapshot) {
                      if (!certSnapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      final docs = certSnapshot.data!.docs;
                      if (docs.isEmpty) {
                        return const Text('인증 기록이 없습니다.');
                      }
                      return ListView(
                        children: docs.map((doc) {
                          final type = doc['type'] ?? '기록';
                          final amount = doc['amount'] ?? '-';
                          final date = (doc['timestamp'] as Timestamp).toDate();
                          return ListTile(
                            title: Text('$type - ${amount.toString()}원'),
                            subtitle: Text('${date.toLocal()}'),
                          );
                        }).toList(),
                      );
                    },
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
