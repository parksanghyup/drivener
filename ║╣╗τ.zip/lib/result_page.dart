import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {
  final double distance;
  final int point;

  const ResultPage({Key? key, required this.distance, required this.point})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('주행 결과')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('총 주행 거리: ${distance.toStringAsFixed(2)} km',
                style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            Text('획득 포인트: $point P', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('홈으로'),
            ),
          ],
        ),
      ),
    );
  }
}
