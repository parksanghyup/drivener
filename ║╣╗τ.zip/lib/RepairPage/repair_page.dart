import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';

class RepairPage extends StatefulWidget {
  const RepairPage({Key? key}) : super(key: key);

  @override
  State<RepairPage> createState() => _RepairPageState();
}

class _RepairPageState extends State<RepairPage> {
  String? selectedItem;
  File? imageFile;
  bool isLoading = false;

  final List<String> items = [
    '엔진오일 교체',
    '타이어 교체',
    '브레이크 패드',
    '에어컨 필터',
    '기타',
  ];

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        imageFile = File(picked.path);
      });
    }
  }

  Future<void> submitRepair() async {
    if (selectedItem == null || imageFile == null) return;

    setState(() => isLoading = true);

    final uid = FirebaseAuth.instance.currentUser!.uid;
    final fileName = '${uid}_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final ref = FirebaseStorage.instance.ref().child('repairs/$fileName');
    await ref.putFile(imageFile!);
    final imageUrl = await ref.getDownloadURL();

    await FirebaseFirestore.instance.collection('repairs').add({
      'uid': uid,
      'item': selectedItem,
      'image': imageUrl,
      'timestamp': Timestamp.now(),
      'point': 20, // 기본 포인트
    });

    // 사용자 포인트 누적도 업데이트
    final userRef = FirebaseFirestore.instance.collection('users').doc(uid);
    await userRef.update({
      'pointTotal': FieldValue.increment(20),
    });

    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('정비 인증이 완료되었습니다! +20P')),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('정비소 인증')),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('정비 항목 선택', style: TextStyle(fontSize: 16)),
                  DropdownButton<String>(
                    value: selectedItem,
                    hint: Text('항목 선택'),
                    isExpanded: true,
                    items: items
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (val) => setState(() => selectedItem = val),
                  ),
                  SizedBox(height: 20),
                  Text('정비 사진 업로드', style: TextStyle(fontSize: 16)),
                  imageFile != null
                      ? Image.file(imageFile!, height: 150)
                      : SizedBox(height: 150, child: Placeholder()),
                  SizedBox(height: 10),
                  ElevatedButton(onPressed: pickImage, child: Text('사진 선택')),
                  Spacer(),
                  ElevatedButton(
                    onPressed: submitRepair,
                    child: Text('정비 인증 제출'),
                    style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(50)),
                  )
                ],
              ),
            ),
    );
  }
}
