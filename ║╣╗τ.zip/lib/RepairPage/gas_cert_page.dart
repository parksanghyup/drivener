
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class GasCertPage extends StatefulWidget {
  const GasCertPage({super.key});

  @override
  State<GasCertPage> createState() => _GasCertPageState();
}

class _GasCertPageState extends State<GasCertPage> {
  final TextEditingController amountController = TextEditingController();
  File? _image;
  bool _isUploading = false;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _submitCertification() async {
    if (_image == null || amountController.text.isEmpty) return;

    setState(() {
      _isUploading = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final fileName = 'gas_certifications/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final ref = FirebaseStorage.instance.ref().child(fileName);
      await ref.putFile(_image!);
      final imageUrl = await ref.getDownloadURL();

      await FirebaseFirestore.instance.collection('certifications').add({
        'userId': user.uid,
        'type': 'gas',
        'amount': int.tryParse(amountController.text) ?? 0,
        'imageUrl': imageUrl,
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('주유 인증이 완료되었습니다.')),
      );

      setState(() {
        _image = null;
        amountController.clear();
      });
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('오류가 발생했습니다. 다시 시도해주세요.')),
      );
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('주유소 인증')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '주유 금액 (원)'),
            ),
            const SizedBox(height: 16),
            _image == null
                ? const Text('영수증 사진을 선택해주세요.')
                : Image.file(_image!, height: 150),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isUploading ? null : _pickImage,
              child: const Text('사진 선택'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isUploading ? null : _submitCertification,
              child: _isUploading ? const CircularProgressIndicator() : const Text('인증 제출'),
            ),
          ],
        ),
      ),
    );
  }
}
