
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MyPage extends StatelessWidget {
  const MyPage({super.key});

  Stream<QuerySnapshot> _certificationsStream() {
    final user = FirebaseAuth.instance.currentUser;
    return FirebaseFirestore.instance
        .collection('certifications')
        .where('userId', isEqualTo: user?.uid)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('마이페이지')),
      body: StreamBuilder<QuerySnapshot>(
        stream: _certificationsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('인증 기록이 없습니다.'));
          }

          final docs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              final type = data['type'] ?? '';
              final amount = data['amount'] ?? 0;
              final imageUrl = data['imageUrl'] ?? '';
              final timestamp = (data['timestamp'] as Timestamp).toDate();

              String typeLabel = '';
              if (type == 'gas') {
                typeLabel = '주유';
              } else if (type == 'repair') {
                typeLabel = '정비';
              } else if (type == 'wash') {
                typeLabel = '세차';
              } else {
                typeLabel = '기타';
              }

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  leading: imageUrl.isNotEmpty
                      ? Image.network(imageUrl, width: 50, height: 50, fit: BoxFit.cover)
                      : const Icon(Icons.receipt_long),
                  title: Text('$typeLabel 인증 - ₩$amount'),
                  subtitle: Text('날짜: ${timestamp.toLocal()}'),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
